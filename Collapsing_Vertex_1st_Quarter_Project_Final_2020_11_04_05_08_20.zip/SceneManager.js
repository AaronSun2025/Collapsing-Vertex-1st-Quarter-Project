menuScene = function() {
    
  background(220);
  
  image(msBackground, 200, 200, 400, 400);
  image(msTitle, 200, 200, 400, 400);
  
  image(btnStart, 200, 200, 400, 400);
  btnSHB.display();
}
  
gameSelectionScene = function() {
  
  background(220);
  
  image(msBackground, 200, 200, 400, 400);
  image(btnTut, 200, 200, 400, 400);
  btnTHB.display();
  image(btnLVL1, 200, 200, 400, 400);
  btn1HB.display();
  image(btnLVL2, 200, 200, 400, 400);
  btn2HB.display();
  image(backArrow, 30, 380, 60, 40);
  btnBHB.display();
  
}

Tutorial = function() {
  textAlign(CENTER, CENTER);
  textSize(20);
  fill(255);
  background(50);
  
  switch(paragraph) {
    case 1:
      text(para1, 200, 200, 200, 200);
      btnBHB.display();
      image(backArrow, 30, 380, 60, 40);
      btnNHB.display();
      image(nextArrow, 370, 380, 60, 40);
      break
    case 2:
      text(para2, 200, 200, 300, 300);
      btnBHB.display();
      image(bgBtn, 30, 380, 60, 40);
      btnNHB.display();
      image(rBtn, 370, 380, 60, 40);
      break
    case 3:
      text(para3, 200, 200, 350, 400);
      btnBHB.display();
      image(backArrow, 30, 380, 60, 40);
      btnNHB.display();
      image(nextArrow, 370, 380, 60, 40);
      break
    case 4:
      text(para4, 200, 200, 300, 400);
      btnBHB.display();
      image(backArrow, 30, 380, 60, 40);
      btnNHB.display();
      image(nextArrow, 370, 380, 60, 40);
      break
    case 5:
      text(para5, 200, 200, 200, 200);
      btnBHB.display();
      image(backArrow, 30, 380, 60, 40);
      btnNHB.display();
      image(nextArrow, 370, 380, 60, 40);
      break
  }
  
}

lvl1 = function() {
  background(220);
  
  for(var i = 0; i < block.length; i++) {
    block[i].display();
    block[i].move();
    if(player.collide(block[i].x, block[i].y, 38)) {
      scene = 8;
      paragraph = 8;
    }
  }
  if(millis() - start >= 60000) {
    scene = 6;
    paragraph = 6;
  }
  player.run();
  
}

lvl2 = function() {
  background(220);
  
  for(var j = 0; j < block.length; j++) {
    block[j].display();
    block[j].move();
    if(player.collide(block[j].x, block[j].y, 38)) {
      scene = 8;
      paragraph = 8;
    }
  }
  if(millis() - start >= 60000) {
    scene = 7;
    paragraph = 7;
  }
  player.run();
  
}
  
winScenelvl1 = function() {
  lvlCom = true;
  
  for(var i = 0; i < block.length; i++) {
    block[i].y = 0 - i * bDist;
  }
  player.pos.y = 380;
  player.pos.x = 200;
  textAlign(CENTER, CENTER);
  textSize(20);
  fill(255);
  background(50);
  
  switch(paragraph) {
    case 6:
      text(para6, 200, 200, 380, 400);
      btnNHB.display();
      image(nextArrow, 370, 380, 60, 40);
      break;
  }
}
  
winScenelvl2 = function() {
  for(var i = 0; i < block.length; i++) {
    block[i].y = 0 - i * bDist;
  }
  player.pos.y = 380;
  player.pos.x = 200;
  textAlign(LEFT, CENTER);
  textSize(20);
  fill(255);
  background(50);
  
  switch(paragraph) {
    case 7:
      text(para7, 200, 200, 380, 400);
      break;
  }
}
  
loseScene = function() {
  for(var i = 0; i < block.length; i++) {
    block[i].y = 0 - i * bDist;
  }
  player.pos.y = 380;
  player.pos.x = 200;
  textAlign(CENTER, CENTER);
  textSize(20);
  fill(255, 0, 0);
  background(40);
  
  switch(paragraph) {
    case 8:
      text(para8, 200, 200, 380, 400);
      btnBHB.display();
      image(backArrow, 30, 380, 60, 40);
      break;
  }
  
}

sceneManager = function() {
  
  switch(scene) {
      case 1:
        menuScene();
        break;
      case 2:
        gameSelectionScene();
        break;
      case 3:
        Tutorial();
        break;
      case 4:
        lvl1();
        break;
      case 5:
        lvl2();
        break;
      case 6:
        winScenelvl1();
        break;
      case 7:
        winScenelvl2();
        break;
      case 8:
        loseScene();
        break;
    }
  
}