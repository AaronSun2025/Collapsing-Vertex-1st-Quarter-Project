function mouseClicked() {
  if(btnSHB.isInsideButton()) {
    btnSHB.handleMouseClick();
  }
  if(btnTHB.isInsideButton()) {
    btnTHB.handleMouseClick();
  }
  if(btn1HB.isInsideButton()) {
    btn1HB.handleMouseClick();
  }
  if(btn2HB.isInsideButton()) {
    btn2HB.handleMouseClick();
  }
  if(btnBHB.isInsideButton()) {
    btnBHB.handleMouseClick();
  }
  if(btnNHB.isInsideButton()) {
    btnNHB.handleMouseClick();
  }
}

function keyPressed() {
  if (keyIsDown(UP_ARROW) && jAmount == 1) {
      jAmount = 0;
      player.vel.y = -4.5;
    }
}