class Obstacles {
  
  constructor(config) {
    this.x = config.x;
    this.y = config.y;
    this.width = 40;
    this.height = 40;
    this.incr = 1;
  }
  
  display() {
    fill(100);
    stroke(0);
    strokeWeight(2);
    
    rect(this.x, this.y, this.width, this.height);
  }
  
  move() {
      this.y += this.incr;
      this.y = constrain(this.y, -40000, 440);
    }
  
}

obstacleManager = function() {
  for(var i = 0; i <= bAmount; i++) {
      block.push(new Obstacles({
        x: random(blockPosX),
        y: blockPosY = 0 - i * bDist,
      }))
    }
}