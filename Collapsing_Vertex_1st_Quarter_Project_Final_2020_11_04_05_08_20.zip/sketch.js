var scene = 1, paragraph = 1;
var msBackground, msTitle, btnStart, btnTut, btnLVL1, btnLVL2, nextArrow, backArrow, corrB, rBtnl, bgBtnl;

var friction = 0.2, jAmount = 1;

var block = [];
var blockPosX = [20, 60, 100, 140, 180, 220, 260, 300, 340, 380];
var blockPosY;
var bAmount = 60, bDist = 50;

var start;

var lvlCom = false;

function setup() {
  createCanvas(400, 400);
  imageMode(CENTER);
  rectMode(CENTER);
  
  obstacleManager();
  buttonManager();
  player = new Character();
  
}

function draw() {
  
  sceneManager();
  
  fill(255);
  //text(mouseX + ", " + mouseY, mouseX + 20, mouseY - 10, 100, 20);
  
}