function preload() {
  
  msBackground = loadImage('Collapsing Vertex Menu Scene Background.png');
  msTitle = loadImage('Collapsing Vertex Menu Scene Title.png');
  btnStart = loadImage('Collapsing Vertex Button Textures Start.png');
  btnTut = loadImage('Collapsing Vertex Button Textures Tutorial.png');
  btnLVL1 = loadImage('Collapsing Vertex Button Textures LvL1.png');
  btnLVL2 = loadImage('Collapsing Vertex Button Textures LvL2.png');
  nextArrow = loadImage('Next Arrow.png');
  backArrow = loadImage('Back Arrow.png');
  corrB = loadImage('Corruption Background.png');
  rBtn = loadImage('Rule Button.png');
  bgBtn = loadImage('Background Button.png');
   
}