class Button {
  
  constructor(config) {
    
    this.x = config.x || 200;
    this.y = config.y || 200;
    this.width = config.width || 100;
    this.height = config.height || 50;
    this.showHB = config.showHB;
    this.onClick = config.onClick || function() {}
    
  }
  
  display() {
    
    if(this.showHB == true) {
      fill(255, 255, 255);
    } else{
      noFill();
    }
    noStroke();
    
    rect(this.x, this.y, this.width, this.height);
  
  }
  
  isInsideButton() {
    
    return mouseX < this.x + this.width/2 &&
           mouseX > this.x - this.width/2 &&
           mouseY > this.y - this.height/2 &&
           mouseY < this.y + this.height/2;
    
  }
  
  handleMouseClick() {
    
    if(this.isInsideButton()) {
      
      this.onClick();
      
    }
    
  }
  
}

function buttonManager() {
  
  btnSHB = new Button({
    
    x: 206,
    y: 238,
    width: 240,
    height: 40,
    showHB: false,
    onClick: function() { if(scene == 1) {scene = 2} }
  
  });
  btnTHB = new Button({
    
    x: 200,
    y: 95,
    width: 150,
    height: 45,
    showHB: false,
    onClick: function() { if(scene == 2) {scene = 3; paragraph = 1} }
  
  });
  btn1HB = new Button({
    
    x: 90,
    y: 150,
    width: 55,
    height: 55,
    showHB: false,
    onClick: function() { if(scene == 2) {scene = 4; start = millis()} }
  
  });
  btn2HB = new Button({
    
    x: 306,
    y: 150,
    width: 55,
    height: 55,
    showHB: false,
    onClick: function() { if(scene == 2 && lvlCom) {scene = 5; start = millis()} }
  
  });
  btnBHB = new Button({
    
    x: 30,
    y: 380,
    width: 60,
    height: 40,
    showHB: false,
    onClick: function() { if(scene == 2) {scene = 1} else if (paragraph == 2) {paragraph++} else {scene = 2} }
  
  });
  btnNHB = new Button({
    
    x: 370,
    y: 380,
    width: 60,
    height: 40,
    showHB: false,
    onClick: function() { if(scene == 6) {scene = 2} else if(paragraph == 5) {scene = 2} else if(paragraph == 2) {paragraph += 2} else {paragraph++} }
  
  });
  
}
