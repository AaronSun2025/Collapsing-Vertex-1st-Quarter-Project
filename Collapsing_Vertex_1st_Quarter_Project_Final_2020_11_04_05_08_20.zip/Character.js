class Character {
	constructor() {
		this.pos = createVector(200, 380);
		this.vel = createVector();
		this.grav = 0.2;
        this.width = 40;
        this.height = 40;
	}

	move() {
		this.vel.y += this.grav;
		this.pos.y += this.vel.y;
        this.pos.x += this.vel.x;
        if (keyIsDown(LEFT_ARROW)) {
          this.pos.x -= 2.5;
          this.pos.x += friction;
        }

        if (keyIsDown(RIGHT_ARROW)) {
          this.pos.x += 2.5;
          this.pos.x -= friction;
        }
      
        if(this.pos.y == 380) {
          jAmount = 1;
        }
        this.pos.x = constrain(this.pos.x, 20, 380);
        this.pos.y = constrain(this.pos.y, 0, 380);
		return this;
	}

	display() {
		fill(255);
        noStroke();
        rect(this.pos.x, this.pos.y, this.width, this.height);
	}

	run() {
		return this.move().display();
	}
    collide(otherX, otherY, otherS) {
      return this.pos.x < otherX + otherS &&
             this.pos.x > otherX - otherS &&
             this.pos.y > otherY - otherS &&
             this.pos.y < otherY + otherS - 5;
    }
}
