var para1 = "What? Hello? Oh my gosh, are you a player? Welcome, how did you get here?";

var para2 = "Oh Sorry for asking so many questions I'm just shocked that there is a player, hello my name is Atad I'm the guide of this game, do you wanna know some background of this game or the Rules?";

var para3 = "So many years ago the creator of this game wanted to make a tetris knock-off but it didn't work. I know what you're thinking 'how unoriginal', but after many attempts he gave up and left us: the code to stay here unfinished. But just a few months earlier we got corrupted by a computer virus, and the A.I. of the virus finished the game for the creator, and now because of the vir- I mean A.I. you have the opportunity to play this game.";

var para4 = "So, how you play: use the arrow keys to move and dodge the blocks as they come down PS: the down arrow doesn't work and the jump will not help you win, it is entirely extra, but the creator of this game put it there to show his teacher that he learned how to program the physics of jumping.";

var para5 = "Without further of do you can Begin";

var para6 = "Alert! Alert! Its me again Atad, turns out the virus doesn't want you here, you somehow angered it, if this virus is not stopped it might fry your device, quick beat the last lvl and the game will shut itself down.";

var para7 = "Warining Do Not Shut Down Your Device:\n 1e3fnI.prep        * * * * * - starting \n IP                       * * * * * - 0.198.134.768 \n user.Info()          * * * * * - $54t62@09#9     1e3fnl.complete * * * * * - true";

var para8 = "MALWARE CORRUPTED";